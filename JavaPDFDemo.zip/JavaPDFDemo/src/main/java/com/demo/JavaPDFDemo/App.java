package com.demo.JavaPDFDemo;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

/**
 * Hello world!
 *
 */
public class App {

	private static final PDFont FONT = PDType1Font.TIMES_ROMAN;
	private static final float FONT_SIZE = 10;
	private static final float LEADING = -1.5f * FONT_SIZE;

	public static void main(String[] args) throws IOException {
		String title1 = "Sujatha Kannan";
		String title2 = "• Mobile: +49 (0) 15141409842 • E-Mail: sujakanraj@gmail.com";
		PDFont font = PDType1Font.TIMES_BOLD_ITALIC;
		int marginTop = 30;
		int fontSize = 16;

		
		
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		String todayDate = formatter.format(date);
		
		String sourceFile1 = "C:\\Users\\713088\\Desktop\\PDFboxfiles\\Resume_Sujatha_"
		+ new SimpleDateFormat("dd-MM-yyyy").format(date) + ".pdf";

		final PDDocument doc = new PDDocument();
		PDPage page = new PDPage(PDRectangle.A4);
		PDRectangle mediaBox = page.getMediaBox();
		doc.addPage(page);

		PDPageContentStream stream = new PDPageContentStream(doc, page);

		float titleWidth = font.getStringWidth(title1) / 1000 * fontSize;
		float titleHeight = font.getFontDescriptor().getFontBoundingBox().getHeight() / 1000 * fontSize;

		float startX = (mediaBox.getWidth() - titleWidth) / 2;
		float startY = mediaBox.getHeight() - marginTop - titleHeight;

		stream.beginText();
		stream.setFont(font, fontSize);
		stream.newLineAtOffset(startX, startY);
		stream.showText(title1);
		stream.endText();

		stream.beginText();
		stream.newLineAtOffset(startX - 100, startY - 14);
		stream.setFont(PDType1Font.TIMES_ITALIC, 11);
		stream.showText(title2);
		stream.endText();

		stream.beginText();
		stream.newLineAtOffset(startX + 240, startY - 44);
		stream.setFont(PDType1Font.TIMES_ROMAN, 10);
		stream.showText("Date: " + todayDate);
		stream.endText();

		stream.beginText();
		stream.newLineAtOffset(startX - 200, startY - 64);
		stream.setFont(PDType1Font.TIMES_ROMAN, 10);
		stream.showText("Dear Recruiting Manager,");
		stream.endText();
		
		
		PDRectangle mb = page.getMediaBox();
		float marginY = 80;
		float marginX = 40;
		float width = mb.getWidth() - 2 * marginX;
		float sX = mb.getLowerLeftX() + marginX;
		float sY = mb.getUpperRightY() - marginY;

		String text = "I am writing this cover letter to apply for a position of Java developer in your esteemed organization. My professional experience includes analysis, design, application development, client management, risk management and project management.";

		stream.beginText();
		addParagraph(stream, width, startX - 200, startY - 90, text, true);		
		stream.endText();
		
		stream.beginText();
		String para2 = "After completing my Bachelor’s in Information Technology, I began my career as a Software Engineer in which I\r\n" + 
				" gained extensive experience in coding and testing using Java, J2EE, Restful, Spring framework, Microservices,\r\n" + 
				" Web development with Javascript, Angular, HTML and database programming using PL/SQ, SQL, NoSQL with\r\n" + 
				" MongoDB. etc. I had involved in several proof of concept tasks for designs which helped me to expand my skills\r\n" + 
				" in analysing and designing solutions to complex requirements. During my tenure as Senior engineer and\r\n" + 
				" Technology Analyst, I had the opportunity to explore several technical concepts. I utilized them appropriately\r\n" + 
				" and provided solutions reducing the turnaround time of the application. My experience as a Technical Lead\r\n" + 
				" allowed me to apply my quantitative reasoning skills to automate tasks which minimized considerable hours of\r\n" + 
				" manual work.";
		addParagraph(stream, width, startX - 200, startY - 130, para2, true);		
		stream.endText();
		
		stream.beginText();
		String para3 = "In addition to my technical experience, I have also spearheaded a team of 10 in technical and process management. I possess very good experience in agile development with Scrum where I had opportunity to learn and apply my agile practices as developer. I had played a role in conducting daily stand up meetings, tracking progress of my scrum team, mentoring my team in scrum practices and participated in sprint planning, review and retrospective meetings. My experience in agile methodology helped me to shape myself a self-organized person.  I have been actively taking part in Defect Prevention Analysis where I have worked with my peers and juniors to analyse possibly recurring defects and their prevention mechanisms. Our continuous effort under my mentorship reduced defect count and the tasks were completed well ahead in deadline gaining appreciation from clients.";
		addParagraph(stream, width, startX - 200, startY - 260, para3, true);		
		stream.endText();

		stream.beginText();
		String para4 = "I am very much passionate in research and development in Java and full stack development. I am flexible, independent, willing to own tasks and passionate learner of new technologies. I am B1 level certified German speaker and can comfortably converse in German. I am constantly pursuing further German level to improve my language. I am prepared for the next challenge in my career. I would like to use my professional and management skills and continue my learning curve in your esteemed organization.";
		addParagraph(stream, width, startX - 200, startY - 390, para4, true);		
		stream.endText();
		
		stream.beginText();
		String para5 = "I am available for joining from 1st December 2018 and my salary expectation is 53,000 Euros per annum.";
		addParagraph(stream, width, startX - 200, startY - 475, para5, true);		
		stream.endText();
		
		stream.beginText();
		String para6 = "With this application, I have forwarded my resume for your kind perusal.  Please contact me if my profile sounds interesting. I will be happy to discuss further with you in detail. Looking forward to hear from you.";
		addParagraph(stream, width, startX - 200, startY - 500, para6, true);		
		stream.endText();

		stream.beginText();
		String para7 = "Thank you for your consideration.";
		addParagraph(stream, width, startX - 200, startY - 550, para7, true);		
		stream.endText();
		
		stream.beginText();
		String para8 = "Yours Sincerely,";
		addParagraph(stream, width, startX - 200, startY - 580, para8, true);		
		stream.endText();
		
		stream.beginText();
		stream.setFont(PDType1Font.TIMES_BOLD, 10);
		String para9 = "Sujatha Kannan ";
		addParagraph(stream, width, startX - 200, startY - 600, para9, true);		
		stream.endText();
		
		stream.close();
 
		doc.save(new File(sourceFile1));

		doc.close();
		
		// MErge
		
		File file = new File("C:\\Users\\713088\\Desktop\\PDFboxfiles\\Sujatha Kannan - Resume.pdf"); 
				PDDocument document = PDDocument.load(file);
				
				PDFMergerUtility PDFmerger = new PDFMergerUtility(); 
				
				PDFmerger.setDestinationFileName("C:\\Users\\713088\\Desktop\\PDFboxfiles\\Application_Document_Sujatha.pdf");

				PDFmerger.addSource(sourceFile1);
				PDFmerger.addSource(file);
				PDFmerger.mergeDocuments();
				document.close();
	}

	private static void addParagraph(PDPageContentStream contentStream, float width, float sx, float sy, String text)
			throws IOException {
		addParagraph(contentStream, width, sx, sy, text, false);
	}

	private static List<String> parseLines(String text, float width) throws IOException {
		List<String> lines = new ArrayList<String>();
		int lastSpace = -1;
		text = text.replace("\n", "").replace("\r", "");
		while (text.length() > 0) {
			int spaceIndex = text.indexOf(' ', lastSpace + 1);
			if (spaceIndex < 0)
				spaceIndex = text.length();
			String subString = text.substring(0, spaceIndex);
		
			float size = FONT_SIZE * FONT.getStringWidth(subString) / 1000;
			if (size > width) {
				if (lastSpace < 0) {
					lastSpace = spaceIndex;
				}
				subString = text.substring(0, lastSpace);
				lines.add(subString);
				text = text.substring(lastSpace).trim();
				lastSpace = -1;
			} else if (spaceIndex == text.length()) {
				lines.add(text);
				text = "";
			} else {
				lastSpace = spaceIndex;
			}
		}
		return lines;
	}

	private static void addParagraph(PDPageContentStream contentStream, float width, float sx, float sy, String text,
			boolean justify) throws IOException {
		List<String> lines = parseLines(text, width);
		contentStream.setFont(FONT, FONT_SIZE);
		contentStream.newLineAtOffset(sx, sy);
		for (String line : lines) {
			float charSpacing = 0;
			if (justify) {
				if (line.length() > 1) {
					float size = FONT_SIZE * FONT.getStringWidth(line) / 1000;
					float free = width - size;
					if (free > 0 && !lines.get(lines.size() - 1).equals(line)) {
						charSpacing = free / (line.length() - 1);
					}
				}
			}
			contentStream.setCharacterSpacing(charSpacing);
			contentStream.showText(line);
			contentStream.newLineAtOffset(0, LEADING);
		}
	}
}
